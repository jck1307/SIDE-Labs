﻿======================
Alfresco Language Pack
======================

Pour la version : 3.x - Interfaces SHARE & Explorer - Pack "tout en un".
Pour la langue  : fr


===========================
Contenu de ce Language Pack
===========================

La traduction de ces fichiers est réalisée par l'outil open-source OmegaT (http://www.omegat.org/).


============
Installation
============

Le pack doit être décompressé dans :
	shared\classes\alfresco\

Exemple : 
Le fichier "slingshot.properties" doit donc se retrouver dans :
	tomcat\shared\classes\alfresco\messages
Les autres fichiers doivent donc se retrouver dans :
	tomcat\shared\classes\alfresco\web-extension\site-webscripts\org\alfresco\...

Editer le fichier "web-client-config-custom.xml"
Retirer les marques de commentaire autour des listes des langues désirées. 
Ne conserver que la et les langues désirées.
Sauvegarder, (re)démarrer Alfresco.

==============
Fonctionnement
==============
	
L'ensemble sera chargé par Share automatiquement, et l'affichage fonction de la variable LOCALE envoyée par le navigateur. 

Exemple dans Firefox 3 : Options / Contenu / panneau "Langues" / bouton "Choisir..." /et placer "Français/France (fr-FR)"
 ou l'un de ses variantes (fr_BE, fr_LU, fr_CH, fr_MC, fr_CA) en tête de liste.

Le choix de la langue dans Explorer se fera en fonction du choix dans la liste déroulante.	
										  
										  
=======================================
Traduction des mails d'invitation SHARE
=======================================

Traduire le sujet du mail :
- éditer alfresco/tomcat/webapps/alfresco/WEB-INF/classes/alfresco/workflow/invite_processdefinition.xml
- mail.parameters.subject = "Invitation à joindre le site " + siteName ;


Traduire le corps du mail :
- éditer /Data Dictionnary/Email Templates/invite/invite-email.ftl
- contenu :

-------------------------------------------------------------------------
<#assign inviterPersonRef=args["inviterPersonRef"]/>
<#assign inviterPerson=companyhome.nodeByReference[inviterPersonRef]/>
<#assign inviteePersonRef=args["inviteePersonRef"]/>
<#assign inviteePerson=companyhome.nodeByReference[inviteePersonRef]/>

Bonjour ${inviteePerson.properties["cm:firstName"]},

Vous avez été invité par ${inviterPerson.properties["cm:firstName"]} ${inviterPerson.properties["cm:lastName"]} à joindre le site '${args["siteName"]}'.

Votre rôle dans ce site sera ${args["inviteeSiteRole"]}.

Pour accepter l'invitation, cliquer sur le lien ci-dessous.

${args["acceptLink"]}

<#if args["inviteeGenPassword"]?exists>
et entrer les informations suivantes :

Nom d'utilisateur: ${args["inviteeUserName"]}
Mot de passe: ${args["inviteeGenPassword"]}

Nous vous conseillons fortement de changer votre mot de passe dès la première connexion.

</#if>
Si vous ne voulez pas vous joindre au site, alors cliquer sur le lien suivant:

${args["rejectLink"]}

Cordialement,
L'équipe Alfresco Share.
-------------------------------------------------------------------------

================================
Groupes de discussion et projets
================================

Voir le groupe de discussion Alfresco Forum pour le statut des Language Packs :
http://www.alfresco.org/forums/viewforum.php?f=16

Sur le forum francophone :
http://forums.alfresco.com/fr/viewtopic.php?f=9&t=2595

Pour télécharger le pack :
http://forge.alfresco.com/projects/languagefr/


=============
Contributeurs
=============

Auteur(s) Originaux                     : L'équipe Alfresco
Traduction originale Anglais - Français : Michael Harlaut
Contributeurs à cette version           : Nicolas Moreau 
                                          Laurent Meunier 
										  Thomas Broyer
										  Kevin Roast
										  Will Abson